#!/usr/bin/env python
from ament_index_python.packages import get_package_share_directory 
from sys import byteorder
import sys
from array import array
from struct import pack
import os

import pyaudio
import wave
import audioop

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


THRESHOLD = 500
CHUNK_SIZE = 1024
FORMAT = pyaudio.paInt16

class RecordingPublisher(Node):
    def __init__(self):
        super().__init__('recording_publisher')
        self.publisher_ = self.create_publisher(String, 'recording', 10)
        self.listening = False
        self.create_timer(1,self.listen) # check once per second

    def listen(self):
        if self.listening:
            return
        else:
            self.listening = True
        ##################################
        # TODO (not required for Assignment 3) Change the audio_path to a parameter
        ##################################
        audio_path = get_package_share_directory('aisd_hearing')
        audio_path =  audio_path + "/recordings"
        device = find_device(sys.argv)
        rate = 16000
        while 1:
            current_time = str(self.get_clock().now().nanoseconds)
            audio_file = "{}/{}.wav".format(audio_path, current_time)

            try:
                record_to_file(audio_file, rate=rate, device=device)
            except:
                print("Error recording audio. Check your audio device index.")
                sys.exit(1)
        
            msg = String()
            msg.data = audio_file
            self.publisher_.publish(msg)

##############################
# There are 6 methods needed from unr_deepspeech_client.py
# Your task here is to figure out which methods those are, and paste them
# here in place of this comment
# You are not required to make those methods part of the
# RecordingPublsher class definition, but that would be better programming style.
##############################

def find_device(args):
    p = pyaudio.PyAudio()
    info = p.get_host_api_info_by_index(0)
    numdevices = info.get('deviceCount')
    
    device = -1
    
    if len(args) > 1 and args[1] != "--ros-args":
        if args[1] == "-1":
            print("\nListing audio devices and exiting: ")
            # Print audio devices
            # Ref: https://stackoverflow.com/a/39677871
            for i in range(0, numdevices):
                if (p.get_device_info_by_host_api_device_index(0, i).get('maxInputChannels')) > 0:
                    print("Input Device id ", i, " - ", p.get_device_info_by_host_api_device_index(0, i).get('name'))
            sys.exit(0)
        else:
            try:
                device = int(args[1])
            except ValueError:
                print("Invalid audio device id.")
                print("usage: ros2 run aisd_hearing recording_publisher [audio_device_index]")
                sys.exit(1)
    elif len(args) == 1 or (len(args) > 1 and args[1] == "--ros-args"): # search for default device        
        for i in range(0, numdevices):
             if (p.get_device_info_by_host_api_device_index(0, i).get('maxInputChannels')) > 0:
                 if p.get_device_info_by_host_api_device_index(0, i).get('name') == 'default':
                     device = i
                     print("Using device {}".format(i))
                     break
        if device == -1:
            print("Unable to find default device. Here are the available audio devices: ")
            for i in range(0, numdevices):
                if (p.get_device_info_by_host_api_device_index(0, i).get('maxInputChannels')) > 0:
                    print("Input Device id ", i, " - ", p.get_device_info_by_host_api_device_index(0, i).get('name'))
            sys.exit(1)
    else:
        print("usage: ros2 run aisd_hearing recording_publisher [audio_device_index]")
        sys.exit(1)

    return device
        
def main(args=None):
   ############################
   # Place the standard code for a publisher here
   ############################
if __name__ == "__main__":
    main()
